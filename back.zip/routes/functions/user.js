const { pool } = require("../../db/database");
const uuid = require("uuid");
const toSend = require("../../verifymail/mail");
const smtpConfig = require("../../verifymail/smtpConfig");
const SimpleCrypto = require("simple-crypto-js").default;

// Register User
const createUser = async (req, res) => {
  try {
    const { key, enc } = req.body;
    console.log("the key: ", key);
    console.log("the data: ", enc);
    console.log(typeof key);
    console.log(typeof enc);
    // const simpleCrypto = new SimpleCrypto(key);
    const simpleCrypto = new SimpleCrypto(`${key}`);
    const decipherData = simpleCrypto.decrypt(`${enc}`);
    // console.log(decipherData);
    const { name, email, telephone, password } = decipherData;
    const userId = uuid.v4(); // Generate UUID for user ID

    // Check if the 'users' table exists, and create it if not
    await pool.query(`
      CREATE TABLE IF NOT EXISTS ezhedgef_ezHedgeFunds.users (
        id VARCHAR(36) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        telephone VARCHAR(20),
        password VARCHAR(255) NOT NULL
      )
    `);

    // Check if the 'wallet' table exists, and create it if not
    await pool.query(`
      CREATE TABLE IF NOT EXISTS ezhedgef_ezHedgeFunds.wallet (
        wallet_id VARCHAR(36) PRIMARY KEY,
        wallet_balance DECIMAL(10, 2) NOT NULL,
        investment_in_progress BOOLEAN NOT NULL
      )
    `);

    // Insert user into the 'users' table
    await pool.query(
      "INSERT INTO ezhedgef_ezHedgeFunds.users (id, name, email, telephone, password) VALUES (?, ?, ?, ?, ?)",
      [userId, name, email, telephone, password]
    );

    // Insert wallet for the user
    await pool.query(
      "INSERT INTO ezhedgef_ezHedgeFunds.wallet (wallet_id, wallet_balance, investment_in_progress) VALUES (?,?,?)",
      [userId, 0, false]
    );

    // Return user data with generated ID
    const userData = {
      id: userId,
      name,
      email,
      telephone,
      password,
    };

    res
      .status(201)
      .json({ message: "User created successfully", user: userData });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error creating user" });
  }
};

// User Log-in
const userLogin = async (req, res) => {
  try {
    // console.log(req.body);
    const { email, password } = req.body;
    const [result] = await pool.query(
      "SELECT * FROM ezhedgef_ezHedgeFunds.users WHERE email=? AND password=?",
      [email, password]
    );

    if (result.length <= 0) {
      res.status(404).json({ message: "email or password not found" });
      console.log("no user found");
    } else {
      const secretKey = SimpleCrypto.generateRandom();
      const simpleCrypto = new SimpleCrypto(secretKey);
      const encryptedData = simpleCrypto.encrypt(result[0]);

      // Set session properties

      req.session.user = result[0].id;
      req.session.loggedIn = true;
      // console.log(req.session);

      res.status(201).json({ message: "user found", userInfo: result[0] });
    }
  } catch (error) {
    console.log(error);
  }
};

// send Link to Email
const sendVerificationLink = async (req, res) => {
  const { name, email } = req.body;
  const secretKey = SimpleCrypto.generateRandom();
  // Create a SimpleCrypto instance
  const simpleCrypto = new SimpleCrypto(secretKey);

  // Assuming req.body is a Buffer
  const dataString = req.body.toString("utf8"); // Or any relevant encoding

  // Encrypt the string
  const encryptedData = simpleCrypto.encrypt(dataString);

  const results = await toSend([smtpConfig], name, email, {
    encryptedData,
    secretKey,
  });
  if (results[0].sentMail) {
    res.status(200).json({ message: "verification link sent to email" });
  } else {
    res.status(503).json({ message: "failed to send mail" });
  }
};

module.exports = { createUser, userLogin, sendVerificationLink };
