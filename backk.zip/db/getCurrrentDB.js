const db = process.env.DB;

module.exports = db